// Функция для запроса с таймаутом
async function fetchWithTimeout(url, timeoutMs = 4000) {
    // Создаём контроллер для отмены запроса
    const ctrl = new AbortController();
    // Таймер отмены запроса через timeoutMs мс
    const id = setTimeout(() => ctrl.abort(), timeoutMs);

    try {
        console.log(`Запрос: ${url} (таймаут ${timeoutMs}мс)`);
        // Выполняем запрос с сигналом отмены
        const res = await fetch(url, { signal: ctrl.signal });
        clearTimeout(id); // Очищаем таймер, если запрос выполнился
        
        if (!res.ok) throw new Error(res.status);
        const data = await res.json();
        console.log('Успех:', data.products?.[0]?.title || data);
    } catch (err) {
        clearTimeout(id); // Очищаем таймер при ошибке
        if (err.name === 'AbortError') {
            console.error(`Таймаут ${timeoutMs}мс`); // Отмена по таймауту
        } else {
            console.error('Ошибка:', err.message); // Другие ошибки
        }
    }
}

// Быстрый запрос (успеет: delay=2000 < таймаут=5000)
fetchWithTimeout('https://dummyjson.com/products?delay=2000&limit=2', 5000);

// Медленный запрос (не успеет: delay=6000 > таймаут=3000)
fetchWithTimeout('https://dummyjson.com/products?delay=6000&limit=2', 3000);