async function fetchWithRetry(url, retries = 3, delay = 800) {
    for (let i = 1; i <= retries; i++) {
        try {
            console.log(`Попытка ${i}/${retries}`);
            const res = await fetch(url);
            
            if (!res.ok) {
                // Если серверная ошибка (5xx) - пробуем снова
                if (res.status >= 500) {
                    console.warn(`Сервер ${res.status}, ждём ${delay * i}мс`);
                    await new Promise(r => setTimeout(r, delay * i));
                    continue;
                }
                // Если клиентская ошибка (4xx) - не повторяем
                throw new Error(`HTTP ${res.status}`);
            }
            
            const data = await res.json();
            console.log(`Успех на попытке ${i}`);
            return data;
            
        } catch (err) {
            if (i === retries) {
                console.error(`Все попытки провалились:`, err.message);
                throw err;
            }
            console.warn(`Попытка ${i} ошибка:`, err.message, '-> повтор через', delay * i, 'мс');
            await new Promise(r => setTimeout(r, delay * i));
        }
    }
}

// Запускаем с обработкой результата
(async () => {
    try {
        const data = await fetchWithRetry('https://dummyjson.com/products?delay=1500&limit=3');
        console.log('Получено продуктов:', data.products.length);
    } catch (e) {
        console.error('Финальная ошибка:', e.message);
    }
})();