
let controller = null;

/**
 @param {string} query
 */
async function searchProducts(query) {
    if (controller) controller.abort();
    
    // Создаём новый контроллер для текущего запроса
    controller = new AbortController();

    try {
        // Логируем начало поиска
        console.log(`Поиск: ${query}`);
        const res = await fetch(`https://dummyjson.com/products/search?q=${encodeURIComponent(query)}&limit=5`, {
            signal: controller.signal  // Привязываем сигнал для отмены
        });
        
        // Если ответ не успешный - выбрасываем ошибку
        if (!res.ok) throw new Error(res.status);
        
        // Преобразуем ответ в JSON
        const data = await res.json();
        
        // Извлекаем только названия продуктов из результата
        const titles = data.products.map(p => p.title);
        
        // Выводим результаты поиска в консоль
        console.log(`Результат для "${query}":`, titles);
        
    } catch (err) {
        if (err.name !== 'AbortError') {
            console.error(`Ошибка для "${query}":`, err.message);
        }
    }
}

/**
 @param {Function} fn - функция для выполнения
 @param {number} ms - задержка в миллисекундах
 @returns {Function} 
 */
function debounce(fn, ms = 600) {
    let timer;  // Идентификатор таймера
    
    // Возвращаем функцию, которая будет вызвана после задержки
    return (...args) => {
        clearTimeout(timer);
        timer = setTimeout(() => fn(...args), ms);
    };
}
const debounced = debounce(searchProducts, 700);
debounced("phone");
setTimeout(() => debounced("smart"), 200);
setTimeout(() => debounced("laptop"), 400);
setTimeout(() => debounced("headphones"), 1200);
